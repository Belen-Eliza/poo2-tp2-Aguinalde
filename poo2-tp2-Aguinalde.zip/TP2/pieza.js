function Pieza(tipo,precioUnidad){
    this.tipo = tipo;
    this.precioUnidad= precioUnidad;
}

module.exports=Pieza;
